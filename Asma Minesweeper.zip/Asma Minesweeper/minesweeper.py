# Python Version 3.8
# File: minesweeper.py

from tkinter import *
from tkinter import messagebox
import random
from collections import deque



class Minesweeper:

    def __init__(s, m):


        s.t_plain = PhotoImage(file = "images/t_plain.gif")
        s.t_clicked = PhotoImage(file = "images/t_clicked.gif")
        s.t_mine = PhotoImage(file = "images/t_mine.gif")
        s.t_flag = PhotoImage(file = "images/t_flag.gif")
        s.t_wrong = PhotoImage(file = "images/t_wrong.gif")
        s.t_no = []
        for x in range(1, 9):
            s.t_no.append(PhotoImage(file = "images/t_"+str(x)+".gif"))

        frame = Frame(m)
        frame.pack()

        s.label1 = Label(frame, text="                M I N E  S W E E P E R                   ",bg="#1a878b", fg="#ffffff")
        s.label1.grid(row = 0, column = 0, columnspan = 10)

        s.flags = 0
        s.correct_flags = 0
        s.clicked = 0

        s.buttons = dict({})
        s.mines = 0
        x_coord = 1
        y_coord = 0
        for x in range(0, 100):
            mine = 0
            
            var = s.t_plain
            
            if random.uniform(0.0, 1.0) < 0.1:
                mine =1
                s.mines += 1

            s.buttons[x] = [ Button(frame, image = var),
                                mine,
                                0,
                                x,
                                [x_coord, y_coord],
                                0 ]
            s.buttons[x][0].bind('<Button-1>', s.lclicked_wrapper(x))
            s.buttons[x][0].bind('<Button-3>', s.rclicked_wrapper(x))

            y_coord += 1
            if y_coord == 10:
                y_coord = 0
                x_coord += 1
        
        for key in s.buttons:
            s.buttons[key][0].grid( row = s.buttons[key][4][0], column = s.buttons[key][4][1] )

        for key in s.buttons:
            nearby_mines = 0
            if s.check_for_mines(key-9):
                nearby_mines += 1
            if s.check_for_mines(key-10):
                nearby_mines += 1
            if s.check_for_mines(key-11):
                nearby_mines += 1
            if s.check_for_mines(key-1):
                nearby_mines += 1
            if s.check_for_mines(key+1):
                nearby_mines += 1
            if s.check_for_mines(key+9):
                nearby_mines += 1
            if s.check_for_mines(key+10):
                nearby_mines += 1
            if s.check_for_mines(key+11):
                nearby_mines += 1

            s.buttons[key][5] = nearby_mines


        s.label2 = Label(frame, text = "BOMBS: "+str(s.mines),bg="#1a878b", fg="#ffffff")
        s.label2.grid(row = 11, column = 1, columnspan = 5)

     
        s.label3 = Label(frame, text = "FLAGS: "+str(s.flags),bg="#1a878b", fg="#ffffff")
        s.label3.grid(row = 11, column = 3, columnspan = 8)




    def check_for_mines(s, key):
        try:
            if s.buttons[key][1] == 1:
                return True
        except KeyError:
            pass

    def lclicked_wrapper(s, x):
        return lambda Button: s.lclicked(s.buttons[x])

    def rclicked_wrapper(s, x):
        return lambda Button: s.rclicked(s.buttons[x])

    def lclicked(s, button_data):
        if button_data[1] == 1: 
            
            for key in s.buttons:
                if s.buttons[key][1] != 1 and s.buttons[key][2] == 2:
                    s.buttons[key][0].config(image = s.t_wrong)
                if s.buttons[key][1] == 1 and s.buttons[key][2] != 2:
                    s.buttons[key][0].config(image = s.t_mine)
             
            s.gameover()
        else:
            
            if button_data[5] == 0:
                button_data[0].config(image = s.t_clicked)
                s.clear_empty_tiles(button_data[3])
            else:
                button_data[0].config(image = s.t_no[button_data[5]-1])

            if button_data[2] != 1:
                button_data[2] = 1
                s.clicked += 1
            if s.clicked == 100 - s.mines:
                s.victory()

    def rclicked(s, button_data):
       
        if button_data[2] == 0:
            button_data[0].config(image = s.t_flag)
            button_data[2] = 2
            button_data[0].unbind('<Button-1>')
        
            if button_data[1] == 1:
                s.correct_flags += 1
            s.flags += 1
            s.update_flags()

        elif button_data[2] == 2:
            button_data[0].config(image = s.t_plain)
            button_data[2] = 0
            button_data[0].bind('<Button-1>', s.lclicked_wrapper(button_data[3]))

            
            if button_data[1] == 1:
                s.correct_flags -= 1
            s.flags -= 1
            s.update_flags()


    def check_tile(s, key, queue):
        try:
            if s.buttons[key][2] == 0:
                if s.buttons[key][5] == 0:
                    s.buttons[key][0].config(image = s.t_clicked)
                    queue.append(key)
                else:
                    s.buttons[key][0].config(image = s.t_no[s.buttons[key][5]-1])
                s.buttons[key][2] = 1
                s.clicked += 1
        except KeyError:
            pass

    def clear_empty_tiles(s, main_key):
        queue = deque([main_key])

        while len(queue) != 0:
            key = queue.popleft()
            s.check_tile(key-9, queue)     
            s.check_tile(key-10, queue)    
            s.check_tile(key-11, queue)    
            s.check_tile(key-1, queue)     
            s.check_tile(key+1, queue)     
            s.check_tile(key+9, queue)     
            s.check_tile(key+10, queue)    
            s.check_tile(key+11, queue)    
    
    def gameover(s):
        messagebox.showinfo("GAME OVER", " You Lose :(")
        global root
        root.destroy()

    def victory(s):
        messagebox.showinfo("CONGRATULATIONS", " You Win :)")
        global root
        root.destroy()

    def update_flags(s):
        s.label3.config(text = "FLAGS: "+str(s.flags))


 

def main():
    global root
    root = Tk()
    

    root.title("MINESWEEPER")
    minesweeper = Minesweeper(root)
    
    root.mainloop()

if __name__ == "__main__":
    main()
